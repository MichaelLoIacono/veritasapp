package de.syntaxinstitut.veritasapp.ui.two

import android.app.Application
import androidx.lifecycle.AndroidViewModel

/**
 * Das ViewModel des One Fragments
 */
class TwoViewModel(application: Application) : AndroidViewModel(application) {
}
